ASCEND V1 — standalone prototype

Open index.html in a modern browser.

Included:
- ASCEND + PULSE branding
- Dark royal-blue / navy visual identity
- Onboarding
- Dashboard
- XP / rank / stats / streak
- Accept Quest
- Modify Quest with temporary adaptations
- PULSE hesitation / Discipline Trial demo
- Quest completion
- Quest history
- Training Academy
- Profile and sound toggle
- Synthesized sci-fi UI sounds
- Mobile-first layout

This build uses local demo state only; refreshing resets the demo.
